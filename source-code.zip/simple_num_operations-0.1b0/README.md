**Hello! Iam thedotaxein, and this is simple_num_operations package!**
**There is GitHub page with documentation! https://github.com/thedotaxein/simplenumoperations**
# Version v0.1b0 (beta) now!
## license thedotaxein, MIT LICENSE!