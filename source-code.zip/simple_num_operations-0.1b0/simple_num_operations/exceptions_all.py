class NotMathsExpression(Exception):
    pass
