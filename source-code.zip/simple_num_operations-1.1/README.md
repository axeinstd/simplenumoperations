**Hello! Iam axeinstd, and this is simple_num_operations package!**
**There is GitHub page with documentation! https://github.com/axeinstd/simplenumoperations**
# Version 1.1 now!
## license axeinstd, MIT LICENSE!